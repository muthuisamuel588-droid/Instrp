In-Step Elite — Front Desk (offline web app)
=============================================

WHAT THIS IS
A self-contained, installable offline web app (PWA). No build step,
no backend — everything runs and stores data in the browser on the
device you install it on.

FILES
  index.html      the app
  manifest.json   makes it installable ("Add to Home Screen")
  sw.js           service worker — caches everything for offline use
  icon-192.png / icon-512.png   app icons

HOW TO USE IT
1. Host these 5 files together on any static web host, e.g.:
     - GitHub Pages
     - Netlify / Vercel (drag-and-drop deploy)
     - a folder served by any static file server
   They must all stay in the same folder and keep their file names.
   (Opening index.html directly from disk with file:// will run the
   app, but browsers block service workers on file://, so true
   offline support requires serving it over http/https — even
   something like `npx serve .` on your own machine works.)

2. Visit the page once while online. This lets the service worker
   cache the app and its scripts.

3. On a phone: open the site in the browser, then use "Add to Home
   Screen" (Safari) or the install prompt / menu (Chrome/Edge/
   Android). It'll behave like a normal app icon, launch full-screen,
   and keep working with the WiFi off or with no signal.

4. On a laptop: most Chromium browsers show an install icon in the
   address bar. Click it to install as a desktop app.

DATA & ACCOUNTS
- All data (students, packages, instructors, sales, lessons, staff
  accounts) is stored locally in the browser via localStorage — it
  never leaves the device and isn't shared between devices.
- The first staff account you create becomes Admin. Set PINs and
  roles for the rest from the Staff tab.
- Because storage is per-browser/per-device, front desk staff on a
  different device or browser will have a separate, empty data set —
  this app does not sync across devices.

UPDATING
If you edit the files later, bump CACHE_VERSION at the top of sw.js
(e.g. "instep-elite-v2") so installed copies pick up the change
instead of serving the old cached version.
