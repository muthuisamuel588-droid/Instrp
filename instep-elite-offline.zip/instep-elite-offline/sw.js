// In-Step Elite Front Desk — offline service worker
// Bump this on any deploy that changes cached files so clients pick up the update.
const CACHE_VERSION = "instep-elite-v1";

const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png",
];

// Third-party scripts the app needs to boot — cached on install so the app
// still starts with no network after the first successful visit.
const RUNTIME_PRECACHE = [
  "https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js",
  "https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js",
  "https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/7.23.5/babel.min.js",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_VERSION);
      // App shell must succeed.
      await cache.addAll(APP_SHELL);
      // CDN scripts are best-effort — don't fail install if one CDN request
      // has trouble; the app will just re-fetch it live next time there's a
      // connection.
      await Promise.all(
        RUNTIME_PRECACHE.map(async (url) => {
          try {
            const res = await fetch(url, { mode: "cors" });
            if (res.ok) await cache.put(url, res);
          } catch (e) {
            // ignore — offline install or blocked CDN
          }
        })
      );
      self.skipWaiting();
    })()
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))
      );
      self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_VERSION);
      const cached = await cache.match(req, { ignoreSearch: true });

      // Cache-first for anything we already have — keeps the app instant
      // and fully usable offline.
      if (cached) {
        // Refresh in the background when online so the next load is current.
        fetch(req)
          .then((res) => {
            if (res && res.ok) cache.put(req, res.clone());
          })
          .catch(() => {});
        return cached;
      }

      // Not cached yet — try the network, fall back to the app shell for
      // navigation requests so the app still opens offline.
      try {
        const res = await fetch(req);
        if (res && res.ok && (req.url.startsWith(self.location.origin) || RUNTIME_PRECACHE.includes(req.url))) {
          cache.put(req, res.clone());
        }
        return res;
      } catch (e) {
        if (req.mode === "navigate") {
          const shell = await cache.match("./index.html");
          if (shell) return shell;
        }
        throw e;
      }
    })()
  );
});
